export const api = {
  //url: 'http://127.0.0.1:8111/pokemons',
  url: 'https://pokeapi.co/api/v2/pokemon',
};
